package Interface;

public interface Channel extends RemoteDesign {

    int Next(int i);
    int Previous(int i);

    int CurrentChannel(int i); 

}
