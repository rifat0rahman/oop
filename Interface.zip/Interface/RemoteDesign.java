package Interface;

public interface RemoteDesign {

    int Up(int i);

    int Down(int i);

    int Next(int i);

    int Previous(int i);
} 
