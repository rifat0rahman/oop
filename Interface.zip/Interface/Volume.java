package Interface;

public interface Volume extends RemoteDesign {

    int Up(int i);
    int Down(int i);
    int CurrentVolume(int i);
}
